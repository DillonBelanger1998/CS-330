// scene header
#pragma once
#include "shape.h"
#include "mesh.h"

class SceneBuilder
{
public:
	static void UBuildScene(vector<GLMesh>& scene);
};



