// shape header
#pragma once

#include "mesh.h"

using namespace std;

class ShapeBuilder
{
public:
	static void UBuildRectangle(GLMesh& mesh);
	static void UBuildRectangle(GLMesh& mesh);

	static void UBuildHollowCylinder(GLMesh& mesh);

	static void UBuildRectangle(GLMesh& mesh);

	static void UBuildSphere(GLMesh& mesh);

	static void UBuildPlane(GLMesh& mesh);

	static void UTranslator(GLMesh& mesh);

};

