// shapes built for project scene

#include <cstdlib>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <vector>
#include <cmath>

#include "shape.h"

using namespace std;

void ShapeBuilder::UBuildRectangle(GLMesh& mesh)
{
	// first rectangle for tablet

	float h = mesh.height;

	mesh.v = {

		-0.5f,	 -0.5f,	 0.0f,

		 0.5f,	 -0.5f,	 0.0f,

		 0.5f,	  0.5f,	 0.0f,

		-0.5f,	  0.5f,	 0.0f,
	};

	UTranslator(mesh);

}
void ShapeBuilder::UBuildRectangle(GLMesh& mesh)
{
	vector<float> c = { mesh.p[0], mesh.p[1], mesh.p[2], mesh.p[3] };

	// second rectangle for tablet
	mesh.v = {

		-0.2f,	 -0.2f,	 -0.2f,

		 0.2f,	 -0.2f,	 -0.2f,

		 0.2f,	  0.2f,	 -0.2f,

		-0.2f,	  0.2f,	 -0.2f,

		-0.2f,	 -0.2f,	  0.2f,

		 0.2f,	 -0.2f,	  0.2f,

		 0.2f,	  0.2f,	  0.2f,

		-0.2f,	  0.2f,	  0.2f,

	};

	UTranslator(mesh);
}

void ShapeBuilder::UBuildHollowCylinder(GLMesh& mesh)
{
	vector<float> c = { mesh.p[0], mesh.p[1], mesh.p[2], mesh.p[3] };

	float r = mesh.radius;
	float l = mesh.length;
	float s = mesh.number_of_sides;

	constexpr float PI = 3.14f;
	const float sectorStep = 2.0f * PI / s;
	const float textStep = 1.0f / s;
	float textureXLoc = 0.0f;

	vector<float> v;

	for (auto i = 1; i < s + 1; i++) {


		
		v.insert(v.end(), { 0.5f, 0.5f, 0.0f, c[0], c[1], c[2], c[3], 0.5f, 0.25f });		// center point;
		v.insert(v.end(), { 0.5f + r * cos(i * sectorStep) ,
										0.5f + r * sin(i * sectorStep) ,
										0.0f ,
										c[0], c[1], c[2], c[3],
			/*textureXLoc,
			0.0f*/
			0.5f + (r * cos((i)*sectorStep)) ,			// texture x;
			0.25f + (0.25f * sin((i)*sectorStep))
			});												
		v.insert(v.end(), { 0.5f + (r * cos((i + 1) * sectorStep)) ,
										0.5f + (r * sin((i + 1) * sectorStep)) ,
										0.0f ,
										c[0], c[1], c[2], c[3],
			/*textureXLoc + textStep,
			0.0f*/
			0.5f + (r * cos((i + 1) * sectorStep)) ,
			0.25f + (0.25f * sin((i + 1) * sectorStep))
			});												


		v.insert(v.end(), { 0.5f + (r * cos(i * sectorStep)) ,
										0.5f + (r * sin(i * sectorStep)) ,
										0.0f ,
										c[0], c[1], c[2], c[3],
										textureXLoc ,
										0.5f });
		v.insert(v.end(), { 0.5f + (r * cos((i + 1) * sectorStep)) ,
										0.5f + (r * sin((i + 1) * sectorStep)) ,
										0.0f ,
										c[0], c[1], c[2], c[3],
										textureXLoc + textStep,
										0.5f });
		v.insert(v.end(), { 0.5f , 0.5f , l , c[0], c[1], c[2], c[3], textureXLoc + (textStep / 2), 1.0f });		// origin

		textureXLoc += textStep;

	}

	mesh.v = v;
	v.clear();	// clear

	UTranslator(mesh);
}

// specified dimensions for the rectangle for the tag

void ShapeBuilder::UBuildRectangle(GLMesh& mesh)
{
	vector<float> c = { mesh.p[0], mesh.p[1], mesh.p[2], mesh.p[3] };

	float r = mesh.radius;
	float l = mesh.length;
	float s = mesh.number_of_sides;
	float h = mesh.height;


	constexpr float PI = 3.14f;
	const float sectorStep = 2.0f * PI / s;

	vector<float> v;

	float vertices[] = {

		-length / 2, -width / 2, -height / 2,  // front bottom left

		length / 2, -width / 2, -height / 2,   // front bottom right

		length / 2, width / 2, -height / 2,    // front top right

		-length / 2, width / 2, -height / 2,   // front top left

		-length / 2, -width / 2, height / 2,  // back bottom left

		length / 2, -width / 2, height / 2,   // back bottom right

		length / 2, width / 2, height / 2,    // back top right

		-length / 2, width / 2, height / 2    // back top left
	}

	mesh.v = v;
	v.clear();
	UTranslator(mesh);

}


void ShapeBuilder::UBuildPlane(GLMesh& mesh)
{
	// built on ground
	vector<float> c = { mesh.p[0], mesh.p[1], mesh.p[2], mesh.p[3] };


	mesh.v = {
		-1.0f,	0.0f,	-1.0f,	0.0f,	1.0f,	0.0f,	1.0f,	0.0f,	1.0f,	// 0
		 0.0f,	0.0f,	 1.0f,	0.0f,	1.0f,	0.0f,	1.0f,	0.5f,	0.0f,	// 1
		-1.0f,	0.0f,	 1.0f,	0.0f,	1.0f,	0.0f,	1.0f,	0.0f,	0.0f,	// 2

		-1.0f,	0.0f,	-1.0f, 	0.0f,	1.0f,	0.0f,	1.0f,	0.0f,	1.0f,	// 0
		 0.0f,	0.0f,	 1.0f,	0.0f,	1.0f,	0.0f,	1.0f,	0.5f,	0.0f,	// 2
		 0.0f,	0.0f,	-1.0f, 	0.0f,	1.0f,	0.0f,	1.0f,	0.5f,	1.0f,	// 3

		 0.0f,	0.0f,	-1.0f, 	0.0f,	1.0f,	0.0f,	1.0f,	0.5f,	1.0f,	// 3
		 0.0f,	0.0f,	 1.0f, 	0.0f,	1.0f,	0.0f,	1.0f,	0.5f,	0.0f,	// 2
		 1.0f,	0.0f,	 1.0f, 	0.0f,	1.0f,	0.0f,	1.0f,	1.0f,	0.0f,	// 5

		 0.0f,	0.0f,	-1.0f, 	0.0f,	1.0f,	0.0f,	1.0f,	0.5f,	1.0f,	// 3
		 1.0f,	0.0f,	 1.0f, 	0.0f,	1.0f,	0.0f,	1.0f,	1.0f,	0.0f,	// 5
		 1.0f,	0.0f,	-1.0f, 	0.0f,	1.0f,	0.0f,	1.0f,	1.0f,	1.0f,	// 4

	};

	UTranslator(mesh);

}
// sphere for the glass

void ShapeBuilder::UBuildSphere(GLMesh& mesh)
{
	vector<float> c = { mesh.p[0], mesh.p[1], mesh.p[2], mesh.p[3] };


	float r = mesh.radius;
	float l = mesh.length;
	float s = mesh.number_of_sides;
	float h = mesh.height;

	constexpr float PI = 3.14f;
	const float sectorStep = 2.0f * PI / s;

	vector<float> v;

	for (int i = 0; i <= segments; i++) {
		double theta = i * M_PI / segments;
		double sinTheta = sin(theta);
		double cosTheta = cos(theta);

		for (int j = 0; j <= segments; j++) {
			double phi = j * 2 * M_PI / segments;
			double sinPhi = sin(phi);
			double cosPhi = cos(phi);

			float x = cosPhi * sinTheta;
			float y = cosTheta;
			float z = sinPhi * sinTheta;

			vertices.push_back(x);
			vertices.push_back(y);
			vertices.push_back(z);

			normals.push_back(x);
			normals.push_back(y);
			normals.push_back(z);
		}
	}

	for (int i = 0; i < segments; i++) {
		for (int j = 0; j < segments; j++) {
			int p0 = i * (segments + 1) + j;
			int p1 = p0 + 1;
			int p2 = (i + 1) * (segments + 1) + j;
			int p3 = p2 + 1;

			indices.push_back(p0);
			indices.push_back(p2);
			indices.push_back(p1);

			indices.push_back(p1);
			indices.push_back(p2);
			indices.push_back(p3);
		}
	}
}
	mesh.v = v;
	v.clear();
	UTranslator(mesh);
}




void ShapeBuilder::UTranslator(GLMesh& mesh)
{
	// building mesh

	constexpr GLuint floatsPerVertex = 3;
	constexpr GLuint floatsPerColor = 4;
	constexpr GLuint floatsPerUV = 2;

	mesh.nIndices = mesh.v.size() / (floatsPerVertex + floatsPerUV + floatsPerColor);

	glGenVertexArrays(1, &mesh.vao);
	glBindVertexArray(mesh.vao);

	// creating VBO
	glGenBuffers(1, &mesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // activate buffer

	// use vector
	glBufferData(
		GL_ARRAY_BUFFER,
		mesh.v.size() * sizeof(float),
		&mesh.v.front(),
		GL_STATIC_DRAW
	); // sends vertex

	// strides vertex coordinates
	constexpr GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV + floatsPerColor);

	// vertex attribute pointers
	 
	// location
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, (void*)0);
	glEnableVertexAttribArray(0);

	// color
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// texture
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(7 * sizeof(float)));
	glEnableVertexAttribArray(2);


	// scalaling
	mesh.scale = glm::scale(glm::vec3(mesh.p[4], mesh.p[5], mesh.p[6]));

	const glm::mat4 rot = glm::mat4(1.0f);

	// rotatation)
	mesh.xrotation = glm::rotate(rot, glm::radians(mesh.p[7]), glm::vec3(mesh.p[8], mesh.p[9], mesh.p[10]));
	mesh.yrotation = glm::rotate(rot, glm::radians(mesh.p[11]), glm::vec3(mesh.p[12], mesh.p[13], mesh.p[14]));
	mesh.zrotation = glm::rotate(rot, glm::radians(mesh.p[15]), glm::vec3(mesh.p[16], mesh.p[17], mesh.p[18]));


	// translation
	mesh.translation = glm::translate(glm::vec3(mesh.p[19], mesh.p[20], mesh.p[21]));

	mesh.model = mesh.translation * mesh.xrotation * mesh.zrotation * mesh.yrotation * mesh.scale;

	mesh.gUVScale = glm::vec2(mesh.p[22], mesh.p[23]);		// scaling texture
	//mesh.gUVScale = glm::vec2(2.0f, 2.0f);		

}

